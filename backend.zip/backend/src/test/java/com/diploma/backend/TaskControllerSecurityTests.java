package com.diploma.backend;

import com.diploma.backend.dto.CreateTaskRequest;
import com.diploma.backend.entity.Priority;
import com.diploma.backend.util.SecurityHelpers;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static com.diploma.backend.entity.Role.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Проверяем ролевой доступ к задачам
 */
@SpringBootTest
@AutoConfigureMockMvc
class TaskControllerSecurityTests {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper om;
    @Autowired SecurityHelpers helper;

    String teacherToken;
    String studentToken;

    @BeforeEach
    void init() throws Exception {
        teacherToken = helper.token("teacher@" + SecurityHelpers.rnd() + ".ex", "p", TEACHER);
        studentToken = helper.token("student@" + SecurityHelpers.rnd() + ".ex", "p", STUDENT);
    }

    @Test
    @DisplayName("STUDENT не может создавать задачу → 403")
    void studentCreateForbidden() throws Exception {
        CreateTaskRequest req = new CreateTaskRequest();
        req.setTitle("T");
        mockMvc.perform(post("/api/tasks")
                        .header("Authorization", helper.bearer(studentToken))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(om.writeValueAsString(req)))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("TEACHER создаёт задачу, STUDENT не может её читать")
    void teacherCreatesStudentDenied() throws Exception {
        // teacher создаёт
        CreateTaskRequest req = new CreateTaskRequest();
        req.setTitle("T");
        req.setPriority(Priority.HIGH);

        String location = mockMvc.perform(post("/api/tasks")
                        .header("Authorization", helper.bearer(teacherToken))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(om.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getHeader("Location");

        // student пытается GET
        mockMvc.perform(get(location)
                        .header("Authorization", helper.bearer(studentToken)))
                .andExpect(status().isForbidden());
    }
}
