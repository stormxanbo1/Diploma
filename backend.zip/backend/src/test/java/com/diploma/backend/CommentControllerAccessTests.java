package com.diploma.backend;

import com.diploma.backend.dto.CreateCommentRequest;
import com.diploma.backend.dto.CreateTaskRequest;
import com.diploma.backend.entity.Role;
import com.diploma.backend.util.SecurityHelpers;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Автор может удалить свой комментарий, чужой — нельзя; STAFF может
 */
@SpringBootTest
@AutoConfigureMockMvc
class CommentControllerAccessTests {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper om;
    @Autowired SecurityHelpers helper;

    String authorToken;
    String strangerToken;
    String staffToken;
    String taskId;

    @BeforeEach
    void init() throws Exception {
        authorToken   = helper.token("auth@" + SecurityHelpers.rnd(), "p", Role.TEACHER);
        strangerToken = helper.token("str@" + SecurityHelpers.rnd(), "p", Role.STUDENT);
        staffToken    = helper.token("staff@" + SecurityHelpers.rnd(), "p", Role.STAFF);

        // автор создаёт задачу
        CreateTaskRequest req = new CreateTaskRequest();
        req.setTitle("With comments");
        String location = mockMvc.perform(post("/api/tasks")
                        .header("Authorization", helper.bearer(authorToken))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(om.writeValueAsString(req)))
                .andReturn().getResponse().getHeader("Location");
        taskId = location.substring(location.lastIndexOf('/') + 1);
    }

    @Test
    @DisplayName("Автор удаляет комментарий → 204, stranger → 403, STAFF → 204")
    void commentDeleteRoles() throws Exception {
        // автор добавляет комментарий
        CreateCommentRequest cReq = new CreateCommentRequest();
        cReq.setText("hello");
        String loc = mockMvc.perform(post("/api/tasks/{id}/comments", taskId)
                        .header("Authorization", helper.bearer(authorToken))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(om.writeValueAsString(cReq)))
                .andReturn().getResponse().getHeader("Location");
        String commentId = loc.substring(loc.lastIndexOf('/') + 1);

        // stranger пытается удалить
        mockMvc.perform(delete("/api/comments/{id}", commentId)
                        .header("Authorization", helper.bearer(strangerToken)))
                .andExpect(status().isForbidden());

        // STAFF удаляет
        mockMvc.perform(delete("/api/comments/{id}", commentId)
                        .header("Authorization", helper.bearer(staffToken)))
                .andExpect(status().isNoContent());
    }
}
