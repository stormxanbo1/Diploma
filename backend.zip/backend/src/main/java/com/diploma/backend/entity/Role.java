package com.diploma.backend.entity;

public enum Role {
    ADMIN, STAFF, TEACHER, STUDENT
}
