package com.diploma.backend.dto;

import lombok.Data;
import jakarta.validation.constraints.*;

@Data
public class CreateProjectRequest {
    @NotBlank
    private String name;
    private String description;
}
