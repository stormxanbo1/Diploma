// src/main/java/com/diploma/backend/service/ResourceService.java
package com.diploma.backend.service;

import com.diploma.backend.dto.CreateResourceRequest;
import com.diploma.backend.dto.ResourceDto;
import com.diploma.backend.entity.Resource;
import com.diploma.backend.entity.Role;
import com.diploma.backend.entity.User;
import com.diploma.backend.repository.ResourceRepository;
import com.diploma.backend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.URI;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ResourceService {

    private final ResourceRepository resourceRepository;
    private final UserRepository     userRepository;

    /**
     * Список ресурсов, доступных текущему пользователю:
     * – ADMIN видит всё;
     * – остальные — если их роль указана в allowedRoles
     *   или они состоят в группе, указанной в allowedGroupIds.
     */
    @Transactional(readOnly = true)
    public List<ResourceDto> listMy(Authentication auth) {
        User me = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new IllegalStateException("Пользователь не найден"));

        // ADMIN видит все ресурсы
        if (me.getRoles().contains(Role.ADMIN)) {
            return resourceRepository.findAll().stream()
                    .map(ResourceDto::fromEntity)
                    .collect(Collectors.toList());
        }

        // Роль пользователя (первую из набора)
        Role myRole = me.getRoles().stream()
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("У пользователя нет роли"));

        // Список ID групп, в которых состоит пользователь
        List<UUID> myGroupIds = me.getGroups().stream()
                .map(g -> g.getId())
                .collect(Collectors.toList());

        // Фильтрация ресурсов
        return resourceRepository.findAll().stream()
                .filter(r -> {
                    boolean byRole  = r.getAllowedRoles() != null
                            && r.getAllowedRoles().contains(myRole);
                    boolean byGroup = r.getAllowedGroupIds() != null
                            && r.getAllowedGroupIds().stream()
                            .anyMatch(myGroupIds::contains);
                    return byRole || byGroup;
                })
                .map(ResourceDto::fromEntity)
                .collect(Collectors.toList());
    }

    /**
     * Создание нового ресурса.
     */
    @Transactional
    public ResourceDto create(CreateResourceRequest req, String userEmail) {
        userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new IllegalStateException("Пользователь не найден"));

        URI uri = URI.create(req.getUrl());
        Resource r = Resource.builder()
                .name(req.getName())
                .type(req.getType())
                .url(uri.toString())
                .allowedRoles(req.getAllowedRoles())
                .allowedGroupIds(req.getAllowedGroupIds())
                .build();

        return ResourceDto.fromEntity(resourceRepository.save(r));
    }

    /**
     * Удаление ресурса по ID.
     */
    @Transactional
    public void delete(UUID id) {
        resourceRepository.deleteById(id);
    }
}
