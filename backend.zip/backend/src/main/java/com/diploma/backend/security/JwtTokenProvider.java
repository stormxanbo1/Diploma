package com.diploma.backend.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class JwtTokenProvider {

    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.access-expiration-minutes}")
    private long accessExpirationMinutes;

    @Value("${jwt.refresh-expiration-hours}")
    private long refreshExpirationHours;

    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    private JwtParser jwtParser() {
        // Правильный способ получить JwtParser с ключом
        return Jwts.parser()
                .setSigningKey(getSigningKey())
                .build();
    }

    /** Генерация access-токена */
    public String generateAccessToken(UUID userId) {
        Date now = new Date();
        Date exp = new Date(now.getTime() + accessExpirationMinutes * 60_000);
        return Jwts.builder()
                .setSubject(userId.toString())
                .setIssuedAt(now)
                .setExpiration(exp)
                .signWith(getSigningKey())   // новый signWith(Key)
                .compact();
    }

    /** Генерация refresh-токена */
    public String generateRefreshToken(UUID userId) {
        Date now = new Date();
        Date exp = new Date(now.getTime() + refreshExpirationHours * 3_600_000);
        return Jwts.builder()
                .setSubject(userId.toString())
                .setIssuedAt(now)
                .setExpiration(exp)
                .signWith(getSigningKey())   // новый signWith(Key)
                .compact();
    }

    /** Валидация любого токена */
    public boolean validateToken(String token) {
        try {
            jwtParser().parseClaimsJws(token);
            return true;
        } catch (JwtException | IllegalArgumentException ex) {
            // Кидаем исключение, чтобы ApiExceptionHandler отдал 401
            throw new BadCredentialsException("INVALID_JWT", ex);
        }
    }

    /** Извлечение userId из токена */
    public UUID getUserIdFromToken(String token) {
        Claims claims = jwtParser()
                .parseClaimsJws(token)
                .getBody();
        return UUID.fromString(claims.getSubject());
    }
}
