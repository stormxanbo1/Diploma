package com.diploma.backend.dto;

import lombok.Data;
import java.time.*;
import java.util.*;

@Data
public class ProjectDto {
    private UUID id;
    private String name;
    private String description;
    private UUID creatorId;
    private LocalDateTime createdAt;
}
