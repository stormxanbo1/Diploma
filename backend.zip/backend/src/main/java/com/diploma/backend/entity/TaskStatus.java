package com.diploma.backend.entity;

public enum TaskStatus {
    TODO, IN_PROGRESS, DONE, ON_HOLD
}
