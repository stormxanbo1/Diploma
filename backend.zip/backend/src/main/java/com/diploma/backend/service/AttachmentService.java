package com.diploma.backend.service;

import com.diploma.backend.dto.AttachmentDto;
import com.diploma.backend.entity.Attachment;
import com.diploma.backend.exception.NotFoundException;
import com.diploma.backend.repository.AttachmentRepository;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import io.minio.GetPresignedObjectUrlArgs;
import io.minio.RemoveObjectArgs;
import io.minio.http.Method;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AttachmentService {
    private final MinioClient minioClient;
    private final AttachmentRepository attachmentRepo;

    public AttachmentDto upload(MultipartFile file) throws Exception {
        String bucket = System.getenv().getOrDefault("MINIO_BUCKET", "app-files");
        String objectName = UUID.randomUUID() + "-" + file.getOriginalFilename();

        // Загружаем в MinIO
        minioClient.putObject(PutObjectArgs.builder()
                .bucket(bucket)
                .object(objectName)
                .stream(file.getInputStream(), file.getSize(), -1)
                .contentType(file.getContentType())
                .build());

        // Сохраняем метаданные
        Attachment att = Attachment.builder()
                .fileName(file.getOriginalFilename())
                .contentType(file.getContentType())
                .size(file.getSize())
                .bucket(bucket)
                .objectName(objectName)
                .uploadedAt(LocalDateTime.now())
                .build();
        Attachment saved = attachmentRepo.save(att);

        // Генерим короткий presigned URL на 7 дней
        String url = minioClient.getPresignedObjectUrl(GetPresignedObjectUrlArgs.builder()
                .method(Method.GET)
                .bucket(bucket)
                .object(objectName)
                .expiry(7 * 24 * 60 * 60)
                .build());

        return AttachmentDto.builder()
                .id(saved.getId())
                .fileName(saved.getFileName())
                .contentType(saved.getContentType())
                .size(saved.getSize())
                .url(url)
                .uploadedAt(saved.getUploadedAt())
                .build();
    }

    public AttachmentDto getUrl(UUID id) throws Exception {
        Attachment att = attachmentRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("Attachment not found"));
        String url = minioClient.getPresignedObjectUrl(GetPresignedObjectUrlArgs.builder()
                .method(Method.GET)
                .bucket(att.getBucket())
                .object(att.getObjectName())
                .expiry(7 * 24 * 60 * 60)
                .build());
        return AttachmentDto.builder()
                .id(att.getId())
                .fileName(att.getFileName())
                .contentType(att.getContentType())
                .size(att.getSize())
                .url(url)
                .uploadedAt(att.getUploadedAt())
                .build();
    }

    public void delete(UUID id) throws Exception {
        Attachment att = attachmentRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("Attachment not found"));
        // Удаляем из MinIO
        minioClient.removeObject(RemoveObjectArgs.builder()
                .bucket(att.getBucket())
                .object(att.getObjectName())
                .build());
        // Удаляем запись из БД
        attachmentRepo.delete(att);
    }
}