// src/main/java/com/diploma/backend/repository/ProjectRepository.java
package com.diploma.backend.repository;

import com.diploma.backend.entity.Project;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface ProjectRepository extends JpaRepository<Project, UUID> {
    /** Метод для списка «моих» проектов */
    List<Project> findByCreatorEmail(String email);
}
