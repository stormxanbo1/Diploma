// src/main/java/com/diploma/backend/dto/CreateResourceRequest.java
package com.diploma.backend.dto;

import com.diploma.backend.entity.Role;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.Set;
import java.util.UUID;

@Data
public class CreateResourceRequest {
    @NotBlank
    private String name;

    @NotBlank
    private String type;

    /** Ссылка на ресурс (строка) */
    @NotBlank
    private String url;

    /** Роли, которым разрешён доступ (если пусто — доступ никому) */
    private Set<Role> allowedRoles;

    /** Идентификаторы групп для доступа */
    private Set<UUID> allowedGroupIds;
}
