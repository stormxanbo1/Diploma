// src/main/java/com/diploma/backend/service/ProjectService.java
package com.diploma.backend.service;

import com.diploma.backend.dto.CreateProjectRequest;
import com.diploma.backend.dto.ProjectDto;
import com.diploma.backend.entity.Project;
import com.diploma.backend.entity.User;
import com.diploma.backend.exception.NotFoundException;
import com.diploma.backend.repository.ProjectRepository;
import com.diploma.backend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProjectService {

    private final ProjectRepository projectRepo;
    private final UserRepository userRepo;
    private final ModelMapper mapper;

    /** Создаёт проект, привязывая его к пользователю-автору */
    public ProjectDto create(CreateProjectRequest req, String creatorEmail) {
        User creator = userRepo.findByEmail(creatorEmail)
                .orElseThrow(() -> new NotFoundException("User not found"));
        Project project = Project.builder()
                .name(req.getName())
                .description(req.getDescription())
                .creator(creator)
                .build();
        Project saved = projectRepo.save(project);
        return toDto(saved);
    }

    /** Возвращает проекты, созданные текущим пользователем */
    public List<ProjectDto> listMy(String userEmail) {
        return projectRepo.findByCreatorEmail(userEmail).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    /** Получает проект, проверяя доступ */
    public ProjectDto getById(UUID id, String userEmail) {
        Project project = projectRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("Project not found"));
        checkAccess(project, userEmail);
        return toDto(project);
    }

    /** Обновляет проект (только автор или STAFF/ADMIN) */
    public ProjectDto update(UUID id, CreateProjectRequest req, String userEmail) {
        Project project = projectRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("Project not found"));
        checkAccess(project, userEmail);
        project.setName(req.getName());
        project.setDescription(req.getDescription());
        Project updated = projectRepo.save(project);
        return toDto(updated);
    }

    /** Удаляет проект (только автор или STAFF/ADMIN) */
    public void delete(UUID id, String userEmail) {
        Project project = projectRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("Project not found"));
        checkAccess(project, userEmail);
        projectRepo.delete(project);
    }

    /** Проверка, что пользователь — автор или имеет роль STAFF/ADMIN */
    private void checkAccess(Project project, String userEmail) {
        boolean isCreator = project.getCreator().getEmail().equals(userEmail);
        boolean isStaffOrAdmin = userRepo.findByEmail(userEmail)
                .map(u -> u.getRoles().stream()
                        .anyMatch(r -> r.name().equals("STAFF") || r.name().equals("ADMIN")))
                .orElse(false);
        if (!isCreator && !isStaffOrAdmin) {
            throw new AccessDeniedException("Доступ запрещён");
        }
    }

    /** Маппинг Project → ProjectDto */
    private ProjectDto toDto(Project project) {
        ProjectDto dto = mapper.map(project, ProjectDto.class);
        dto.setCreatorId(project.getCreator().getId());
        return dto;
    }
}
