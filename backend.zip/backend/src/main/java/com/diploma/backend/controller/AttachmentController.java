// src/main/java/com/diploma/backend/controller/AttachmentController.java
package com.diploma.backend.controller;

import com.diploma.backend.dto.AttachmentDto;
import com.diploma.backend.service.AttachmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

@RestController
@RequestMapping("/api/attachments")
@RequiredArgsConstructor
public class AttachmentController {
    private final AttachmentService attachmentService;

    /** Загрузка файла */
    @PostMapping
    public ResponseEntity<AttachmentDto> upload(@RequestParam("file") MultipartFile file) throws Exception {
        AttachmentDto dto = attachmentService.upload(file);
        return ResponseEntity.status(201).body(dto);
    }

    /** Получение presigned URL */
    @GetMapping("/{id}")
    public ResponseEntity<AttachmentDto> getUrl(@PathVariable UUID id) throws Exception {
        AttachmentDto dto = attachmentService.getUrl(id);
        return ResponseEntity.ok(dto);
    }

    /** Удаление */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) throws Exception {
        attachmentService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
