// src/main/java/com/diploma/backend/dto/CreateCommentRequest.java
package com.diploma.backend.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CreateCommentRequest {
    @NotBlank
    private String text;
}
