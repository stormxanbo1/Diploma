// src/main/java/com/diploma/backend/repository/ResourceRepository.java
package com.diploma.backend.repository;

import com.diploma.backend.entity.Resource;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ResourceRepository extends JpaRepository<Resource, UUID> {
    // Все фильтрации выполняются в сервисе через resourceRepository.findAll()
}
