// src/main/java/com/diploma/backend/controller/ProjectController.java
package com.diploma.backend.controller;

import com.diploma.backend.dto.ProjectDto;
import com.diploma.backend.dto.CreateProjectRequest;
import com.diploma.backend.service.ProjectService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/projects")
@RequiredArgsConstructor
@Validated
public class ProjectController {

    private final ProjectService projectService;

    /** Создание нового проекта с указанием автора */
    @PostMapping
    public ResponseEntity<ProjectDto> create(
            @Valid @RequestBody CreateProjectRequest req,
            Authentication auth) {
        ProjectDto dto = projectService.create(req, auth.getName());
        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }

    /** Список проектов текущего пользователя */
    @GetMapping
    public List<ProjectDto> listMy(Authentication auth) {
        return projectService.listMy(auth.getName());
    }

    /** Получить проект по ID */
    @GetMapping("/{id}")
    public ResponseEntity<ProjectDto> getById(@PathVariable UUID id,
                                              Authentication auth) {
        ProjectDto dto = projectService.getById(id, auth.getName());
        return ResponseEntity.ok(dto);
    }

    /** Обновление проекта */
    @PutMapping("/{id}")
    public ResponseEntity<ProjectDto> update(
            @PathVariable UUID id,
            @Valid @RequestBody CreateProjectRequest req,
            Authentication auth) {
        ProjectDto dto = projectService.update(id, req, auth.getName());
        return ResponseEntity.ok(dto);
    }

    /** Удаление проекта */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id,
                                       Authentication auth) {
        projectService.delete(id, auth.getName());
        return ResponseEntity.noContent().build();
    }
}
