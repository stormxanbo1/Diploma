// src/main/java/com/diploma/backend/service/CommentService.java
package com.diploma.backend.service;

import com.diploma.backend.dto.CommentDto;
import com.diploma.backend.dto.CreateCommentRequest;
import com.diploma.backend.entity.*;
import com.diploma.backend.exception.NotFoundException;
import com.diploma.backend.repository.*;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CommentService {

    private final TaskRepository taskRepo;
    private final ProjectRepository projectRepo;
    private final CommentRepository commentRepo;
    private final UserRepository userRepo;
    private final ModelMapper mapper;

    /* ---------- создать ---------- */

    public CommentDto addToTask(UUID taskId, CreateCommentRequest req, String authorEmail) {
        Task task = taskRepo.findById(taskId)
                .orElseThrow(() -> new NotFoundException("Task not found"));
        User author = userRepo.findByEmail(authorEmail)
                .orElseThrow(() -> new NotFoundException("User not found"));

        Comment c = Comment.builder()
                .text(req.getText())
                .author(author)
                .task(task)
                .build();
        return toDto(commentRepo.save(c));
    }

    public CommentDto addToProject(UUID projectId, CreateCommentRequest req, String authorEmail) {
        Project project = projectRepo.findById(projectId)
                .orElseThrow(() -> new NotFoundException("Project not found"));
        User author = userRepo.findByEmail(authorEmail)
                .orElseThrow(() -> new NotFoundException("User not found"));

        Comment c = Comment.builder()
                .text(req.getText())
                .author(author)
                .project(project)
                .build();
        return toDto(commentRepo.save(c));
    }

    /* ---------- списки ---------- */

    public List<CommentDto> listTask(UUID taskId) {
        return commentRepo.findByTask_IdOrderByCreatedAt(taskId).stream()
                .map(this::toDto).collect(Collectors.toList());
    }

    public List<CommentDto> listProject(UUID projectId) {
        return commentRepo.findByProject_IdOrderByCreatedAt(projectId).stream()
                .map(this::toDto).collect(Collectors.toList());
    }

    /* ---------- удалить (автор или STAFF/ADMIN) ---------- */

    public void delete(UUID commentId, String userEmail) {
        Comment c = commentRepo.findById(commentId)
                .orElseThrow(() -> new NotFoundException("Comment not found"));

        boolean isAuthor = c.getAuthor().getEmail().equals(userEmail);
        boolean isStaffOrAdmin = userRepo.findByEmail(userEmail)
                .map(u -> u.getRoles().stream()
                        .anyMatch(r -> r.name().equals("STAFF") || r.name().equals("ADMIN")))
                .orElse(false);

        if (!isAuthor && !isStaffOrAdmin) {
            throw new AccessDeniedException("Доступ запрещён");
        }
        commentRepo.delete(c);
    }

    /* ---------- helper ---------- */

    private CommentDto toDto(Comment c) {
        CommentDto dto = mapper.map(c, CommentDto.class);
        dto.setAuthorId(c.getAuthor().getId());
        return dto;
    }
}
